﻿Option Strict On

Imports System.Net
Imports System.Net.Sockets
Imports NAudio.Wave
Imports System.IO
Imports NAudio.CoreAudioApi.MMDevice
Imports System
Imports System.Threading
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Text = "Recieve"
        Me.Location = New Point(CInt((Screen.PrimaryScreen.WorkingArea.Width / 2) - (Me.Width / 2)), CInt((Screen.PrimaryScreen.WorkingArea.Height / 2) - (Me.Height / 2)))

    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As EventArgs) Handles Me.FormClosing
        Try
            AbortVoxViaUDPThread = True
        Catch ex As Exception
        End Try
        Try
            VoxViaUDP.Abort()
            PlayingThread.Abort()
        Catch ex As Exception
        End Try
        Try
            VoxViaUDPRxClient.Close()
            Application.Exit()
        Catch ex As Exception
        End Try
    End Sub

    Dim VoxViaUDP As System.Threading.Thread
    Dim PlayingThread As System.Threading.Thread

    Dim VoxViaUDPIPAddress As IPAddress
    Dim VoxViaUDPLogicalPortNumber As Integer = 4012
    Dim PortNumber As IPEndPoint

    Dim VoxViaUDPRemoteIpEndPoint As New System.Net.IPEndPoint(System.Net.IPAddress.Any, 0)
    Dim VoxViaUDPRxClient As System.Net.Sockets.UdpClient

    Dim threadName1 As String = "thread1"
    Dim threadName2 As String = "thread2"

    Private Sub Receive_Vox_Click(sender As Object, e As EventArgs) Handles Receive_Vox.Click

        Stop_Receiving.Enabled = True
        Receive_Vox.Enabled = False
        Try
            VoxViaUDP.Abort()
        Catch ex As Exception
        End Try
        Try
            VoxViaUDPRxClient.Close()
        Catch ex As Exception
        End Try

        VoxViaUDPRxClient = New UdpClient()
        VoxViaUDPRxClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, True)
        VoxViaUDPRxClient.Client.Bind(New IPEndPoint(IPAddress.Any, 4012))
        PortNumber = New IPEndPoint(IPAddress.Any, 4012)
        AbortVoxViaUDPThread = False

        VoxViaUDP = New System.Threading.Thread(AddressOf VoxViaUDPReceivingThread)
        PlayingThread = New System.Threading.Thread(AddressOf VoxViaUDPPlayingThread)

        VoxViaUDP.Name = threadName1
        PlayingThread.Name = threadName2

        VoxViaUDP.Start()

    End Sub

    Dim BytesRcvd As Integer = 0
    Dim AbortVoxViaUDPThread As Boolean = False

    Dim RcvdWaveFileBytes As New List(Of Byte()) ' A List of Byte Arrays per index, not just single bytes per index.
    Dim TempPlayingTemp2 As New List(Of Byte())

    Dim flagPlagThread As Boolean = False
    Dim flagBufferState As Boolean = True
    Private Sub VoxViaUDPReceivingThread()

        Try
            Do
                Dim TempBytes() As Byte
                If AbortVoxViaUDPThread = False Then

                    Do
                        Try
                            If flagBufferState = True Then
                                Exit Do
                            End If
                        Catch ex As Exception
                        End Try
                    Loop

                    flagBufferState = True
                    TempBytes = VoxViaUDPRxClient.Receive(PortNumber)
                    RcvdWaveFileBytes.Add(TempBytes)
                    TempPlayingTemp2.Add(TempBytes)
                    flagBufferState = False

                Else
                    Exit Do
                End If

                If flagThreadState = False And RcvdWaveFileBytes.Count > 5 Then
                    PlayingThread.Start()
                    flagThreadState = True
                End If

                If RcvdWaveFileBytes.Count < 6 Then
                    flagBufferState = True
                End If
            Loop
        Catch ex As Exception
        End Try
    End Sub


    Dim flagThreadState As Boolean = False

    Dim recieveData(38400) As Byte
    Dim tempPlayingTemp As New List(Of Byte())
    Private Sub VoxViaUDPPlayingThread()
        Try
            Do
                Do
                    Try
                        If flagBufferState = False Then
                            Exit Do
                        End If
                    Catch ex As Exception
                    End Try
                Loop

                flagBufferState = False
                RcvdWaveFileBytes(0).CopyTo(recieveData, 0)
                'Buffer.BlockCopy(RcvdWaveFileBytes(0), 0, recieveData, 0, RcvdWaveFileBytes(0).Length)
                ReDim Preserve recieveData(RcvdWaveFileBytes(0).Length - 1)
                tempPlayingTemp.Add(recieveData)
                RcvdWaveFileBytes.RemoveRange(0, 1)
                flagBufferState = True

                CreateWaveHeaderAndPlay()

                ReDim recieveData(38400)

            Loop
        Catch ex As Exception
        End Try
    End Sub

    Dim FileType() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes("RIFF")          ' The ASCII text string "RIFF", 4 bytes.
    Dim FileSize() As Byte                                                             ' The file size not including the "RIFF" description (4 bytes) and header type "WAVE" (4 bytes). This is file size - 8. Or Wave Data size + 36 which is all byte counts except RIFF and WAVE bytes.
    Dim HeaderType() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes("WAVE")        ' The ASCII text string "WAVE", 4 bytes.
    Dim Format() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes("fmt ")            ' The ASCII text string "fmt "(The space is also included), 4 bytes including one of anything.
    Dim FormatLength() As Byte                                                         ' The size of the WAVE type format. This is usually 16 but can be other sizes. I use 16 for this code. 4 bytes.
    Dim WaveTypePCM() As Byte                                                          ' Type of WAVE format. This is a PCM header = 01. Other values indicates some forms of compression. 2 bytes.
    Dim Channels() As Byte                                                             ' Channels 1 for mono, 2 for stereo. 2 bytes.
    Dim SamplesHertz() As Byte                                                         ' Samples Hz is number of samples per second, or frequency in hertz and is 4 bytes.
    Dim BytesPerSecond() As Byte                                                       ' BytesPerSecond is "Number of channels * Samples per second * Bits per Sample / 8". 4 bytes.
    Dim Align() As Byte                                                                ' Align is "Number of channels * Bits per Sample / 8". 2 bytes.
    Dim BitsPerSample() As Byte                                                        ' Bits per sample is usually 32, 24, 16 or 8. Using 16 for this code. 2 bytes.
    Dim DataDescHeader() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes("data")    ' The data description header is the ASCII text string "data". 4 bytes.
    Dim SizeOfData() As Byte                                                           ' Number of bytes of data within the data section. 4 bytes.
    Dim WaveData As New List(Of Byte)                                                  ' The wave data.
    Dim CompleteWaveFile() As Byte
    Dim NumberofChannels As Integer = 2
    Dim SamplingRate As Integer = 48000

    Private Sub CreateWaveHeaderAndPlay()

        WaveData.AddRange(recieveData)
        FileSize = WaveFileHelper(WaveData.Count + 36, 4)
        FormatLength = WaveFileHelper(16, 4)
        WaveTypePCM = WaveFileHelper(1, 2)
        Channels = WaveFileHelper(NumberofChannels, 2)
        SamplesHertz = WaveFileHelper(SamplingRate, 4)
        Dim BPS As Integer = CInt(2 * SamplingRate * 16 / 8)
        BytesPerSecond = WaveFileHelper(BPS, 4)
        Dim AlignInfo As Integer = CInt(2 * 16 / 8)
        Align = WaveFileHelper(AlignInfo, 2)
        BitsPerSample = WaveFileHelper(16, 2)
        SizeOfData = WaveFileHelper(WaveData.Count, 4)
        Using MS As New IO.MemoryStream
            MS.Write(FileType, 0, FileType.Length)              ' 4 bytes
            MS.Write(FileSize, 0, FileSize.Length)             ' 4 bytes
            MS.Write(HeaderType, 0, HeaderType.Length)         ' 4 bytes
            MS.Write(Format, 0, Format.Length)                 ' 4 bytes
            MS.Write(FormatLength, 0, FormatLength.Length)     ' 4 bytes
            MS.Write(WaveTypePCM, 0, WaveTypePCM.Length)       ' 2 bytes
            MS.Write(Channels, 0, Channels.Length)             ' 2 bytes
            MS.Write(SamplesHertz, 0, SamplesHertz.Length)     ' 4 bytes
            MS.Write(BytesPerSecond, 0, BytesPerSecond.Length) ' 4 bytes
            MS.Write(Align, 0, Align.Length)                   ' 2 bytes
            MS.Write(BitsPerSample, 0, BitsPerSample.Length)   ' 2 bytes
            MS.Write(DataDescHeader, 0, DataDescHeader.Length) ' 4 bytes
            MS.Write(SizeOfData, 0, SizeOfData.Length)         ' 4 bytes
            MS.Write(WaveData.ToArray, 0, WaveData.Count)      ' Number of bytes determined by sampled data
            CompleteWaveFile = MS.ToArray
        End Using
        Try
            Using MS As New IO.MemoryStream(CompleteWaveFile)
                Dim player As New Media.SoundPlayer(MS)
                player.Play()
            End Using
        Catch ex As Exception
        End Try
    End Sub

    Private Function WaveFileHelper(ByRef Value As Integer, ByRef Length As Integer) As Byte()
        Dim b() As Byte = BitConverter.GetBytes(Value)
        Dim Helper As New List(Of Byte)
        Helper = b.ToList
        Return Helper.GetRange(0, Length).ToArray
    End Function

    Private Sub Stop_Receiving_Click(sender As Object, e As EventArgs) Handles Stop_Receiving.Click
        Try
            AbortVoxViaUDPThread = True
        Catch ex As Exception
        End Try
        Try
            VoxViaUDP.Abort()
            PlayingThread.Abort()
        Catch ex As Exception
        End Try
        Try
            VoxViaUDPRxClient.Close()
        Catch ex As Exception
        End Try
        Stop_Receiving.Enabled = False
        Receive_Vox.Enabled = True
    End Sub


    Dim WaveData1 As New List(Of Byte)
    Dim CompleteWaveFile1() As Byte


    Private Sub CreateWaveHeaderAndPlay1()
        WaveData1.Clear()
        For i = 0 To tempPlayingTemp.Count - 1 Step 1
            WaveData1.AddRange(tempPlayingTemp(i)) ' Add indexes 0 to 24 byte arrays to WaveData from RcvdWaveFileBytes
        Next

        'RcvdWaveFileBytes.RemoveRange(0, 50) ' Remove indexes 0 to 24 (25 total indexes) from RcvdWaveFileBytes
        FileSize = WaveFileHelper(WaveData1.Count + 36, 4)
        FormatLength = WaveFileHelper(16, 4)
        WaveTypePCM = WaveFileHelper(1, 2)
        Channels = WaveFileHelper(NumberofChannels, 2)
        SamplesHertz = WaveFileHelper(SamplingRate, 4)
        Dim BPS As Integer = CInt(2 * SamplingRate * 16 / 8)
        BytesPerSecond = WaveFileHelper(BPS, 4)
        Dim AlignInfo As Integer = CInt(2 * 16 / 8)
        Align = WaveFileHelper(AlignInfo, 2)
        BitsPerSample = WaveFileHelper(16, 2)
        SizeOfData = WaveFileHelper(WaveData1.Count, 4)
        Using MS As New IO.MemoryStream
            MS.Write(FileType, 0, FileType.Length)             ' 4 bytes
            MS.Write(FileSize, 0, FileSize.Length)             ' 4 bytes
            MS.Write(HeaderType, 0, HeaderType.Length)         ' 4 bytes
            MS.Write(Format, 0, Format.Length)                 ' 4 bytes
            MS.Write(FormatLength, 0, FormatLength.Length)     ' 4 bytes
            MS.Write(WaveTypePCM, 0, WaveTypePCM.Length)       ' 2 bytes
            MS.Write(Channels, 0, Channels.Length)             ' 2 bytes
            MS.Write(SamplesHertz, 0, SamplesHertz.Length)     ' 4 bytes
            MS.Write(BytesPerSecond, 0, BytesPerSecond.Length) ' 4 bytes
            MS.Write(Align, 0, Align.Length)                   ' 2 bytes
            MS.Write(BitsPerSample, 0, BitsPerSample.Length)   ' 2 bytes
            MS.Write(DataDescHeader, 0, DataDescHeader.Length) ' 4 bytes
            MS.Write(SizeOfData, 0, SizeOfData.Length)         ' 4 bytes
            MS.Write(WaveData1.ToArray, 0, WaveData1.Count)      ' Number of bytes determined by sampled data
            CompleteWaveFile1 = MS.ToArray
        End Using
        Using MS As New IO.MemoryStream(CompleteWaveFile1)
            Dim player As New Media.SoundPlayer(MS)
            player.Play()
        End Using
    End Sub



    Dim WaveData2 As New List(Of Byte)
    Dim CompleteWaveFile2() As Byte
    Private Sub CreateWaveHeaderAndPlay2()
        WaveData2.Clear()
        For i = 0 To TempPlayingTemp2.Count - 1 Step 1
            WaveData2.AddRange(TempPlayingTemp2(i)) ' Add indexes 0 to 24 byte arrays to WaveData from RcvdWaveFileBytes
        Next
        'RcvdWaveFileBytes.RemoveRange(0, 50) ' Remove indexes 0 to 24 (25 total indexes) from RcvdWaveFileBytes
        FileSize = WaveFileHelper(WaveData2.Count + 36, 4)
        FormatLength = WaveFileHelper(16, 4)
        WaveTypePCM = WaveFileHelper(1, 2)
        Channels = WaveFileHelper(NumberofChannels, 2)
        SamplesHertz = WaveFileHelper(SamplingRate, 4)
        Dim BPS As Integer = CInt(2 * SamplingRate * 16 / 8)
        BytesPerSecond = WaveFileHelper(BPS, 4)
        Dim AlignInfo As Integer = CInt(2 * 16 / 8)
        Align = WaveFileHelper(AlignInfo, 2)
        BitsPerSample = WaveFileHelper(16, 2)
        SizeOfData = WaveFileHelper(WaveData2.Count, 4)
        Using MS As New IO.MemoryStream
            MS.Write(FileType, 0, FileType.Length)             ' 4 bytes
            MS.Write(FileSize, 0, FileSize.Length)             ' 4 bytes
            MS.Write(HeaderType, 0, HeaderType.Length)         ' 4 bytes
            MS.Write(Format, 0, Format.Length)                 ' 4 bytes
            MS.Write(FormatLength, 0, FormatLength.Length)     ' 4 bytes
            MS.Write(WaveTypePCM, 0, WaveTypePCM.Length)       ' 2 bytes
            MS.Write(Channels, 0, Channels.Length)             ' 2 bytes
            MS.Write(SamplesHertz, 0, SamplesHertz.Length)     ' 4 bytes
            MS.Write(BytesPerSecond, 0, BytesPerSecond.Length) ' 4 bytes
            MS.Write(Align, 0, Align.Length)                   ' 2 bytes
            MS.Write(BitsPerSample, 0, BitsPerSample.Length)   ' 2 bytes
            MS.Write(DataDescHeader, 0, DataDescHeader.Length) ' 4 bytes
            MS.Write(SizeOfData, 0, SizeOfData.Length)         ' 4 bytes
            MS.Write(WaveData2.ToArray, 0, WaveData2.Count)      ' Number of bytes determined by sampled data
            CompleteWaveFile2 = MS.ToArray
        End Using
        Using MS As New IO.MemoryStream(CompleteWaveFile2)
            Dim player As New Media.SoundPlayer(MS)
            player.Play()
        End Using
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CreateWaveHeaderAndPlay1()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        CreateWaveHeaderAndPlay2()
    End Sub
End Class